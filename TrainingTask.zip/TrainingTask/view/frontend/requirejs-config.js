var config = {
    config: {
        mixins: {
            'Magento_Checkout/js/action/place-order': {
                'RLTSquare_TrainingTask/js/order/place-order-mixin': true
            },
        }
    }
};
