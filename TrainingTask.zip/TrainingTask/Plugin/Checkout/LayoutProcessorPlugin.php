<?php
declare(strict_types=1);

namespace RLTSquare\TrainingTask\Plugin\Checkout;

use Magento\Checkout\Block\Checkout\LayoutProcessor;
use Rltsquare\TrainingTask\Helper\Data;

/**
 * Plugin Class
 */
class LayoutProcessorPlugin
{
    /**
     * @var Data
     */
    private Data $data;

    /**
     * @param Data $data
     */
    public function __construct(
        Data $data
    ){

        $this->data = $data;
    }

    /**
     * @param LayoutProcessor $subject
     * @param array $jsLayout
     * @return array
     */
    public function afterProcess(
        LayoutProcessor $subject,
        array  $jsLayout
    ) {
        if ($this->data->getCustomerGroup() == 2) {
            $jsLayout['components']['checkout']['children']['steps']['children']['shipping-step']['children']
            ['shippingAddress']['children']['before-form']['children']['flower_setting'] = [
                'component' => 'Magento_Ui/js/form/element/date',
                'config' => [
                    'customScope' => 'shippingAddress',
                    'template' => 'ui/form/field',
                    'elementTmpl' => 'ui/form/element/date',
                    'options' => [],
                    'id' => 'flower_instructions'
                ],
                'dataScope' => 'shippingAddress.flower_instructions',
                'label' => __('Flower Setting Instruction'),
                'provider' => 'checkoutProvider',
                'visible' => true,
                'validation' => [],
                'sortOrder' => 200,
                'id' => 'flower_instructions'
            ];
        }

        return $jsLayout;
    }

}
